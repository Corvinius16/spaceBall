
class Container{
    constructor(){

    }
}

export {Container};